$("marquee").hover(function() {
  this.stop();
}, function() {
  this.start();
});
